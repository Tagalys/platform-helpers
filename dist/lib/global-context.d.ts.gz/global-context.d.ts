declare class GlobalContext {
    configuration: any;
    shopifyConfiguration: any;
    set(opts: any): void;
    getConfiguration(): any;
    getShopifyConfiguration(): any;
}
declare const _default: GlobalContext;
export default _default;
